function clicksubmit(){
    $('#submit-button').trigger('click');
}
function auto_comment(){
    triggerClick();
}
function triggerClick(){
    $("#simplebox-placeholder").trigger('click');
    chrome.storage.local.get(['comment','comments'],function(result_comment){
        //var comments = result_comment.comment.split('\n');
        console.log(result_comment);
        var comments = result_comment.comments;
        var one_comment = comments[Math.ceil(Math.random() * comments.length) - 1];
        $('#contenteditable-root').text(one_comment);
    });
    $('#submit-button').removeAttr("disabled");
    setTimeout("triggerSubmit()",500);
}
function triggerSubmit(){
    clicksubmit();
    setTimeout("sendDoneMessage()",1500);
}

function sendDoneMessage(){
    chrome.runtime.sendMessage({type: "commented"});
}
function checkCanComment(){
    var node = document.getElementById("simplebox-placeholder");
    if( node == null){
        chrome.runtime.sendMessage({type: "commented"});
    }
}
function swichAccount(){
    var swichNode = $($('ytd-popup-container iron-dropdown yt-multi-page-menu-section-renderer div ytd-compact-link-renderer')[3]);
    console.log(swichNode);
    swichNode.click();
    setTimeout("clickAnotherAccount()",1000);
}
function clickAnotherAccount(){
    var sections = $('ytd-popup-container ytd-multi-page-menu-renderer ytd-account-section-list-renderer div').eq(4);
    var itemRender = sections.children('ytd-account-item-renderer');
    itemRender.click();
    console.log(itemRender);
}
function triggerSwitchAccount(){
    $('#avatar-btn').click();
    console.log($('ytd-popup-container.style-scope.ytd-app'));
    var di = 0;
    $('ytd-popup-container.style-scope.ytd-app').bind("DOMNodeInserted", function(e){
        if(e.target.className == 'style-scope ytd-compact-link-renderer')
            di = di + 1;
            if(di == 80){
                console.log(e);
                setTimeout("swichAccount()",1000);
            }
    });
}

console.log("login.js loaded");
var account;
chrome.runtime.onMessage.addListener(function(message, sender) {
    console.log(message);
    account = message;
    if(account.op == 'select'){
        $('input#identifierId').val(account.accountName);
        $('div#identifierNext').click();
        setTimeout("inputPassowrd()",1500); 
    }else if(account.op == 'click'){
        setTimeout("inputPassowrd()",500);  
    }
});

function inputPassowrd(){
    console.log('password is ' + account.password);
    console.log($(':password:last'));
    console.log($('input#identifierId'));
    setTimeout("clickPasswordNext()",1000);
}

function clickPasswordNext() {
    $(':password:last').val(account.password);
    $('div#passwordNext').click();
}